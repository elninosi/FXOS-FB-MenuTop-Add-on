# FXOS-FB-MenuTop-Add-on
Firefox OS add-on for Facebook app - menu always stays on top.

Left picture without add-on, right picture with add-on installed.
![before-after](https://cloud.githubusercontent.com/assets/11082452/11996566/e5e1d76e-aa65-11e5-970d-4c2a1faed0db.jpg)
